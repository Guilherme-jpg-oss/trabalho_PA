﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using OpenAI;
using OpenAI.Chat;
using OpenAI.Models;
using System.IO.Compression;
using System.Text;

namespace Services.Services
{
    public class ChatGptServices
    {
        private readonly IConfiguration _configuration;
        private readonly UtilitiesServices _utilities;

        public ChatGptServices(IConfiguration configuration)
        {
            _configuration = configuration;
            _utilities = new UtilitiesServices();
        }

        public async Task<Models.ComplementationResponse> CreateComplementation(Models.ComplementationRequest request)
        {
            string apiKey = _configuration?.GetSection("Api-Key")?.Value ?? throw new Exception("Não foi possível recuperar a API Key da OpenAI na AppSettings. Por favor, verificar!");
            using var openAIClient = new OpenAIClient(apiKey);

            if (Guid.TryParse(request.SessionId, out Guid sessionId) == false)
            {
                sessionId = Guid.NewGuid();
            }

            string history = $"O PrevenBot está auxiliando e tirando dúvidas do usuário {request.Name} sobre a prevenção e deve dar dicas de como tratar as doenças infecciosas. O PrevenBot deve ser fornecer a informação em tempo real sobre todas as doenças infecciosas e fornecer também uma fonte parao usuário verificar a resposta. O PrevenBot não pode em qualquer momento fugir do tema de doenças, independente da pergunta do usuário caso ela seja fora do escopo de doenças.\n";

            string question;
            string prompt = history + $"{request.Name}: " + request.Question + "\nQuickBot: ";

            question = await GenerateQuestion(openAIClient, prompt, sessionId);

            return new Models.ComplementationResponse
            {
                SessionId = sessionId,
                Name = request.Name,
                Message = question,
            };
        }

        private async Task<string> GenerateQuestion(OpenAIClient openAIClient, string prompt, Guid sessionId)
        {
            var messages = new List<Message>
        {
            new Message(Role.System, "You are a helpful assistant."),
            new Message(Role.User, prompt)
        };

            var chatRequest = new ChatRequest(messages, Model.GPT3_5_Turbo, maxTokens: 500, user: sessionId.ToString());
            var response = await openAIClient.ChatEndpoint.GetCompletionAsync(chatRequest);
            var choice = response.FirstChoice;

            _utilities.GerarLog(sessionId, chatRequest, response, "Chat", false);

            return choice.Message;
        }
    }
}