document.addEventListener('DOMContentLoaded', async () => {
  const messageInput = document.getElementById('message-input');
  const history = document.getElementById('history');
  const sendButton = document.querySelector('.btn-outline-secondary');

  let userName = sessionStorage.getItem('userName');  // Recuperar o nome do sessionStorage, se disponível
  let sessionId = sessionStorage.getItem('sessionId');  // Recuperar o sessionId do sessionStorage, se disponível

  sendButton.addEventListener('click', sendMessage);
  messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      sendMessage();
    }
  });

  if (userName) {
    await sendStandardMessage(null);  // Enviar mensagem padrão se o nome já está salvo
  } else {
    askUserName();  // Solicitar o nome se não estiver disponível
  }

  function askUserName() {
    appendMessage("Por favor, digite seu nome:", 'response-message');
  }

  function sendMessage() {
    const message = messageInput.value.trim();
    if (message !== '') {
      appendMessage(message, 'my-message');
      messageInput.value = '';
      if (!userName) {
        userName = message;  // Armazenar temporariamente o nome
        confirmUserName(userName);
      } else {
        // Processar a mensagem do usuário como parte da conversa normal
        //processUserMessage(message);
        sendStandardMessage(message);
      }
    }
  }

  function confirmUserName(name) {
    appendMessage(`Seu nome é ${name}, correto?`, 'response-message');
    appendConfirmationButtons();
  }

  function appendConfirmationButtons() {
    const messageElement = document.createElement('div');
    messageElement.className = "box-response-message";
    messageElement.innerHTML = `
          <div class="response-message">
              <button onclick="confirmResponse(true)">Sim</button>
              <button onclick="confirmResponse(false)">Não</button>
          </div>`;
    history.appendChild(messageElement);
    history.scrollTop = history.scrollHeight;
  }

  window.confirmResponse = function (confirm) {
    if (confirm) {
      sessionStorage.setItem('userName', userName);  // Salvar o nome confirmado no sessionStorage
      appendMessage("Obrigado por confirmar, " + userName + "!", 'response-message');
      sendStandardMessage();
    } else {
      userName = null;  // Resetar o nome do usuário
      askUserName();  // Pedir o nome novamente
    }
  }

  async function sendStandardMessage(message) {
    var request = {
      name: userName
    };

    if (sessionId && message != null) {
      request = {
        sessionId: sessionId,
        name: userName,
        question: message
      }
    }

    // Realizar chamada POST ao servidor
    await fetch('http://localhost:5126/api/ChatGpt/CreateComplementation', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(request)
    })
      .then(response => response.json())
      .then(resp => {
        sessionStorage.setItem('sessionId', resp.data.sessionId);  // Salvar o sessionId
        sessionId = sessionStorage.getItem('sessionId');
        appendMessage(resp.data.message, 'response-message');  // Exibir a mensagem do servidor
      })
      .catch(error => {
        console.error('Error:', error);
        appendMessage("Houve um problema com a conexão. Tente novamente mais tarde.", 'response-message');
      });
  }

  function appendMessage(text, className) {
    const messageElement = document.createElement('div');
    messageElement.className = `box-${className}`;
    messageElement.innerHTML = `<div class="${className}">${text}</div>`;
    history.appendChild(messageElement);
    history.scrollTop = history.scrollHeight;
  }
});
